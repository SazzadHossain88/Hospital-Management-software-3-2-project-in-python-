import pytest
@pytest.mark.django_db

class TestProject:
    def test_user(self,client):
        response = client.get('/user/')
        assert response.status_code==200
        assert len(response.context['datas']) == 5
