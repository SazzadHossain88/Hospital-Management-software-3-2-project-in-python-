import pytest
@pytest.mark.django_db

class TestProject:
    def test_restaurants_view(self,client):
        response = client.get('/myapp/restaurants/')
        assert len(response.context['food_list']) == 40
