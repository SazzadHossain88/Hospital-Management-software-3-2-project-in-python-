from django.db import models

class Doctor(models.Model):
    Did = PrimaryKey(int, auto=True)
    DName = Required(str)
    DeptName = Required(str)
    Age = Required(int)
    BloodGroup = Required(str)
    Dateofbirth = Required(date)
    Address = Required(str)
    Email = Required(str)
    MobileNo = Required(int)
    pres_doctors = Set("PresDoctor")
    patient_doctors = Set("PatientDoctor")
    department = Required("Department")
