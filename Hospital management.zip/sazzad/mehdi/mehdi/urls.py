"""mehdi URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.8/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Add an import:  from blog import urls as blog_urls
    2. Add a URL to urlpatterns:  url(r'^blog/', include(blog_urls))
"""
from django.conf.urls import include, url
from django.contrib import admin
from . import views,javascript
urlpatterns = [
    url(r'^admin/', include(admin.site.urls)),
    url(r'^$',views.index,name='index'),

    url(r'^history/',views.myhistory,name='history'),
    url(r'^useroutpatient/',views.myuseroutpatient,name='useroutpatient'),
    url(r'^msgdg/',views.mymsgdg,name='msgdg'),
    url(r'^onlineappoint/',views.myonlineappoint,name='onlineappoint'),
    url(r'^healthqueries/',views.myhealthqueries,name='healthqueries'),
    url(r'^ambulance/',views.myambulance,name='ambulance'),
    url(r'^health/',views.myhealth,name='health'),
    url(r'^complement/',views.mycomplement,name='complement'),
    url(r'^pharmacyservice/',views.mypharmacyservice,name='pharmacyservice'),
    url(r'^contactus/',views.mycontactus,name='contactus'),
    url(r'^ccu/',views.myccu,name='ccu'),
    url(r'^deptlocation/',views.mydeptlocation,name='deptlocation'),
    url(r'^diagtest/',views.mydiagtest,name='diagtest'),
    url(r'^publisharticle/',views.mypublisharticle,name='publisharticle'),
    url(r'^journal/',views.myjournal,name='journal'),
    url(r'^deptdetails/',views.mydeptdetails,name='deptdetails'),
    url(r'^finddoctors/',views.myfinddoctors,name='finddoctors'),

    url(r'^login/',views.mylogin,name='login_window'),
    url(r'^user/',views.afterlogin,name='afterlogin'),
    url(r'^profile/',views.mydoctorprofile,name='doctorprofile'),
    url(r'^doctor/',views.Doctorpage,name='doctorpage'),
    url(r'^pharmacy/',views.medicinestaff,name='medpage'),
    url(r'^reception/',views.afterreception,name='afterreception'),
    url(r'^prescription/',views.doctorprescription,name='prescription'),
    url(r'^prescribe/',views.prescription,name='prescribe'),
    url(r'^inpatient/',views.inpatient,name='inpatient'),
    url(r'^lab/',views.labview,name='labpage'),
    url(r'^appointment/',views.appointments,name='appointpage'),
    url(r'^receptionsave/',javascript.receptionSave,name='save_reception'),

    ]
