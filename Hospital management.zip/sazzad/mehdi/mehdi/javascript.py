from django.shortcuts import render

# Create your views here.

from django.template import Context, loader
from django.http import HttpResponse,JsonResponse
from django.db import connection
from collections import namedtuple
from django.shortcuts import render_to_response 
from django.template import RequestContext


def receptionSave(request):
	if request.method=="POST":
		print(request.POST.get('patient_id'))
		pid=request.POST.get('patient_id')

		
		data={}
		return JsonResponse(data)


